#GA BEWD Midterm
#Lucas Paolella

#File for calling the Ui class.

require_relative "lib/ui"

Ui.main