# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
MovieApp::Application.config.secret_key_base = '252f2f69a3a0684ad44a70270c1ab26d0ad542840ca156561df31461d477bd4faa3457ac84bbf44643efd24c15d267dd91e3ddb928993a6bc69df403a9530330'
