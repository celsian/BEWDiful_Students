# Be sure to restart your server when you modify this file.

MovieApp::Application.config.session_store :cookie_store, key: '_movie_app_session'
